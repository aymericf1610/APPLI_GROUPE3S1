# esme2526

## Generate code for the app

```bash
flutter pub run build_runner build
```
